# Triển khai demo trên hosting miễn phí

## Kiến trúc được chọn

Ứng dụng hiện dùng PHP thuần, PDO và cú pháp MySQL/MariaDB. Đường triển khai ít thay đổi nhất là **hosting PHP có MySQL tích hợp**, ví dụ InfinityFree cho bản demo. Dữ liệu nằm trong MySQL của cùng tài khoản hosting; host, tên database, username và password phải lấy trong control panel, không mặc định `localhost`.

Supabase Free cung cấp PostgreSQL, không phải MySQL. Không thể thay `DB_HOST` là chạy: schema, kiểu dữ liệu, truy vấn, transaction và các đoạn đặc thù MySQL hiện tại cần được chuyển đổi và kiểm thử riêng. Tài liệu Supabase nêu giới hạn dung lượng cơ sở dữ liệu Free 500 MB và có thể tạm dừng project Free không hoạt động trong một tuần; nếu chọn Supabase sau này cần làm một dự án migration riêng. Với PHP host chỉ có IPv4, Supabase khuyên dùng pooler theo session khi cần kết nối trực tiếp.

Gói hosting miễn phí phù hợp thử nghiệm/portfolio, không nên dùng làm cam kết dịch vụ cho cửa hàng thật hoặc lưu dữ liệu nhạy cảm: tài nguyên, khả dụng, hỗ trợ, email gửi đi và giới hạn vận hành phụ thuộc nhà cung cấp và có thể đổi. Xác minh các thông số hiện hành trong control panel/điều khoản trước khi chọn. SMTP đi ra ngoài và kết nối HTTPS từ PHP đến Google cần được thử trên đúng tài khoản hosting.

## Chuẩn bị hosting và database

1. Tạo website/domain trong hosting control panel, bật HTTPS và chọn PHP **8.1 trở lên**. Google API Client đã khóa trong Composer yêu cầu PHP 8.1+. Chỉ chọn InfinityFree nếu account/control panel hiện tại cho chọn PHP version tương thích; không suy ra tính năng/version từ tên gói miễn phí.
2. Tạo MySQL database/user bằng công cụ hosting. Ghi lại host, port, database name, username và password. Không tạo database bằng SQL `CREATE DATABASE` trên shared host nếu nhà cung cấp không cấp quyền đó.
3. Tạo database phù hợp trong phpMyAdmin, sau đó import `database/schema.sql`. Chỉ import `database/du_lieu_mau.sql` nếu đang tạo dữ liệu demo; không đưa dữ liệu mẫu/tài khoản thử vào website công khai.
4. Cấu hình ứng dụng bằng biến môi trường `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS` nếu host hỗ trợ. Nếu không, sao chép `support/config/database.example.php` thành `support/config/database.local.php` và điền thông tin do hosting cấp. Không commit hoặc chia sẻ file local này.
5. Tạo tài khoản Admin bằng một trong các cách sau:
   - Chạy `support/scripts/khoitao_csdl.php` bằng PHP CLI trỏ tới đúng database nếu hosting cấp CLI và quyền cần thiết. Script yêu cầu database tồn tại/được cấp quyền, tạo Admin và in mật khẩu ngẫu nhiên một lần; lưu mật khẩu đó an toàn.
   - Nếu không có CLI, tạo hash bằng PHP CLI trên máy riêng (`password_hash($password, PASSWORD_DEFAULT)`), rồi dùng phpMyAdmin chèn một bản ghi vào `nhanvien` với email Admin riêng, hash đó, `vai_tro='Admin'`, `trang_thai=1`. Không gửi mật khẩu thô qua chat, không dùng mật khẩu công khai/mặc định và không đưa script khởi tạo có quyền ghi/xóa lên website.
6. Chạy `composer --working-dir=support install --no-dev --optimize-autoloader` trên máy có PHP 8.1+; upload thư mục `support/vendor/` cùng ứng dụng. Nếu máy build chỉ có PHP 8.0 thì dùng Composer/PHP 8.1+ trong môi trường build khác, không bỏ qua kiểm tra platform cho bản phát hành.
7. Upload mã nguồn và `support/vendor/`; loại bỏ test, dump chứa dữ liệu riêng và `.env`. Chỉ upload file cấu hình local cần thiết khi host không hỗ trợ biến môi trường, bảo vệ chúng khỏi HTTP và không đưa chúng lên Git. Trỏ document root về thư mục ứng dụng nếu hosting cho phép. Dùng HTTPS và kiểm tra các URL/đường dẫn sau khi upload.

Nếu buộc phải đặt file cấu hình local dưới document root, giữ `support/config/.htaccess` để chặn truy cập HTTP trực tiếp; xác nhận host hỗ trợ quy tắc Apache này. Tốt hơn nữa, đặt cấu hình ở ngoài document root nếu hosting hỗ trợ và cập nhật đường dẫn cấu hình tương ứng.

Nếu database cũ đã có bảng `khachhang`, chạy migration `google_sub` một lần trước khi bật đăng nhập Google; script `support/scripts/khoitao_csdl.php` có thể cần quyền tạo database không có trên shared host. Trên phpMyAdmin, xem `database/schema.sql` để lấy định nghĩa cột/index cần bổ sung, kiểm tra cấu trúc trước khi chạy lệnh migration và sao lưu database trước mọi thay đổi.

## Bật Google Sign-In thật

1. Trong Google Cloud Console, tạo/chọn project và cấu hình Google Auth Platform (branding, audience và email hỗ trợ). Khi ứng dụng còn ở trạng thái Testing, thêm các tài khoản test. Việc publish/verification phụ thuộc cấu hình và chính sách Google hiện hành.
2. Tạo OAuth Client ID loại **Web application**. Thêm origin HTTPS chính xác của website vào **Authorized JavaScript origins**, ví dụ `https://shop.example.com`. Thêm `https://shop.example.com/controller/index.php?act=google_login` vào **Authorized redirect URIs** nếu Google Console chấp nhận chính xác URI callback dùng bởi trang; phải trùng URL `login_uri` thực tế, bao gồm scheme, host và path.
3. Điền `GOOGLE_CLIENT_ID` và `APP_URL` vào biến môi trường hosting. Nếu không có giao diện biến môi trường, sao chép `support/config/google.example.php` thành `support/config/google.local.php`, điền Client ID và URL HTTPS chuẩn, rồi giữ file này ngoài Git. Client ID dùng phía trình duyệt nên không phải secret; không cần/không được đặt client secret vào file này.
4. Truy cập trang đăng nhập/đăng ký từ domain HTTPS chuẩn và thử tài khoản Google đã được phép. Callback POST kiểm tra double-submit CSRF cookie, xác minh chữ ký/audience/issuer/expiry của ID token qua Google API Client, yêu cầu email đã xác minh, rồi mới tạo/liên kết khách hàng theo Google `sub`. Không thể kiểm chứng end-to-end cho tới khi có domain và Client ID thật.
5. Nếu callback báo lỗi, xem PHP error log của host và kiểm tra thời gian hệ thống, HTTPS, Client ID, callback URL, dependency `support/vendor/` và khả năng kết nối HTTPS outbound tới Google. Không bật chế độ bỏ qua xác minh token để “sửa” lỗi deploy.

## Sau khi upload: smoke test và vận hành

- Tạo tài khoản Google mới, đăng nhập lại cùng tài khoản, thử một email đã có trong bảng khách hàng và một tài khoản bị khóa. Xác nhận chỉ có một khách hàng cho cùng `google_sub`.
- Tạo đơn demo và xác nhận sản phẩm/kho, đơn hàng, chi tiết, email nội bộ và lịch sử đơn thay đổi trong MySQL. Thử tài khoản khác để xác nhận không thể xem đơn/thư của người khác.
- Kiểm tra nút theo dõi chỉ nhận ID đơn hợp lệ; kiểm tra thêm/khóa nhân viên chỉ thao tác được bởi Admin và bằng POST.
- Các form Admin phải gửi CSRF token và chỉ nhận POST cho thao tác ghi. Mật khẩu plaintext/MD5 cũ được chuyển sang `password_hash()` sau lần đăng nhập thành công; yêu cầu người quản trị đổi sang mật khẩu mạnh trước khi vận hành công khai.
- Kiểm tra mail OTP thật. Nếu nhà cung cấp chặn SMTP, đăng ký mật khẩu sẽ báo gửi thất bại và OTP không được hiển thị; dùng Google Sign-In hoặc một dịch vụ email được hosting cho phép.
- Sao lưu SQL thường xuyên, thử khôi phục trên database thử, dùng mật khẩu duy nhất và không lưu dữ liệu thanh toán nhạy cảm. Trang hiện không tích hợp cổng thanh toán.
- Chạy bộ test local trước mỗi lần phát hành: `php support/tests/test_luong.php`. Bộ này không thay thế thử nghiệm trên hosting thực tế.

## Giới hạn xác nhận

Chưa có domain, OAuth Client ID, thông tin hosting/database hay SMTP của chủ dự án nên chưa thể xác nhận Google login, HTTPS outbound, email, hiệu năng hoặc khả năng khôi phục trên InfinityFree. Đây là checklist triển khai và đường kiến trúc phù hợp với code hiện tại, không phải xác nhận production-readiness của một gói miễn phí.

## Tài liệu tham chiếu

- [Google Identity Services: Integrate Sign in with Google](https://developers.google.com/identity/gsi/web/guides/integrate)
- [Google Identity Services: Verify the Google ID token](https://developers.google.com/identity/gsi/web/guides/verify-google-id-token)
- [Supabase pricing and Free plan limits](https://supabase.com/pricing)
- [Supabase: Connect to your database](https://supabase.com/docs/guides/database/connecting-to-postgres)
- [InfinityFree](https://www.infinityfree.com/) — xác minh PHP version, SSL, giới hạn, database và chính sách mail/outbound trong control panel/support hiện hành trước khi triển khai.
